package vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import controlador.ClienteController;

public class ClienteView {
    private ClienteController clienteController;

    public ClienteView(ClienteController clienteController) {
        this.clienteController = clienteController;
    }

    public void mostrarClientes() {
        // Lógica para mostrar la lista de clientes
        JButton verClientesButton = new JButton("Ver Clientes");
        verClientesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para ver clientes y descargar PDF
                clienteController.descargarPdfClientes();
            }
        });
        // Agregar el botón a la interfaz
    }
}