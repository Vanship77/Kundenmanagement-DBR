package vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import controlador.ClienteController;

public class ClienteView {
    private ClienteController clienteController; // Cambié el nombre de la variable a minúscula para seguir las convenciones de Java
    private JFrame frame; // Agregamos un JFrame para la interfaz

    public ClienteView(ClienteController clienteController) {
        this.clienteController = clienteController;

        // Configuración del JFrame
        frame = new JFrame("Gestión de Clientes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300); // Tamaño de la ventana
        frame.setLocationRelativeTo(null); // Centrar la ventana en la pantalla

        // Llamamos al método para mostrar los componentes
        mostrarClientes();
    }

    public void mostrarClientes() {
        // Lógica para mostrar la lista de clientes
        JButton verClientesButton = new JButton("Ver Clientes");
        verClientesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para ver clientes y descargar PDF
                clienteController.descargarPdfClientes();
            }
        });

        // Agregar el botón a la interfaz
        JPanel panel = new JPanel(); // Crear un panel para contener el botón
        panel.add(verClientesButton); // Agregar el botón al panel

        frame.getContentPane().add(panel); // Agregar el panel al contenido del JFrame
        frame.setVisible(true); // Hacer visible el JFrame
    }

    public static void main(String[] args) {
        // Aquí puedes crear una instancia de ClienteController y ClienteView para probar
        ClienteController clienteController = new ClienteController(); // Asegúrate de que este constructor exista
        new ClienteView(clienteController); // Crear la vista
    }
}