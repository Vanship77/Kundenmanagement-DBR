package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import servicio.ClienteService; // Importar la interfaz
import servicio.ClienteServiceImplement; // Importar la implementación
import modelo.Cliente; // Importar la clase Cliente

public class ClienteTable {
    public static void main(String[] args) {
        // Crear el servicio de clientes usando la implementación
        ClienteService ClienteService = new ClienteServiceImplement(); // Esto está bien
        List<Cliente> Clientes = ClienteService.listar();

        // Crear la ventana
        JFrame frame = new JFrame("Lista de Clientes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 400); // Aumenté el tamaño para acomodar más columnas

        // Crear el modelo de tabla
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Nombre");
        model.addColumn("Apellido");
        model.addColumn("Dirección");
        model.addColumn("Teléfono");
        model.addColumn("Tipo de Documento");
        model.addColumn("Número de Documento");
        model.addColumn("Username");
        model.addColumn("Password");

        // Agregar los clientes al modelo de tabla
        for (Cliente cliente : Clientes) {
            model.addRow(new Object[]{
                    cliente.getId(),
                    cliente.getNombre(),
                    cliente.getApellido(),
                    cliente.getDireccion(),
                    cliente.getTelefono(),
                    cliente.getTipoDocumento(),
                    cliente.getNumeroDocumento(),
                    cliente.getUsername(),
                    cliente.getPassword()
            });
        }

        // Crear la tabla
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Mostrar la ventana
        frame.setVisible(true);
    }
}