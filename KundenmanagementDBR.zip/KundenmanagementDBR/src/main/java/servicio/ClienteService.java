package servicio;

import modelo.Cliente;
import java.util.List;

public interface ClienteService {
    void agregarCliente(Cliente cliente);
    List<Cliente> obtenerClientes();
    Cliente autenticar(String username, String password);

    List<Cliente> listar();
}