package servicio;

import modelo.Cliente;

import java.util.Arrays;
import java.util.List;

public class ClienteServiceImplement implements ClienteService {
    @Override
    public List<Cliente> listar() {
        return Arrays.asList(
                new Cliente(1, "Camilo", "San Francisco", "215799664", "Cédula", "1234567890"),
                new Cliente(2, "Andrea", "Juan Ulloa", "283787754", "Cédula", "0987654321"),
                new Cliente(3, "Mayte", "Antonio Garcia", "486745278", "Pasaporte", "A123456789"),
                new Cliente(4, "Alonso", "Cuenca", "667879387", "Cédula", "1122334455"),
                new Cliente(5, "Juan", "Esmeraldas", "475786937", "Cédula", "2233445566"),
                new Cliente(6, "Pedro", "Manabi", "456797793", "Pasaporte", "B987654321")
        );
    }
}