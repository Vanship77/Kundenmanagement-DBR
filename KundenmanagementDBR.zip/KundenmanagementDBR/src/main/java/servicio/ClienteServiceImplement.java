package servicio;

import modelo.Cliente;
import java.util.ArrayList;
import java.util.List;

public class ClienteServiceImplement implements ClienteService {
    private List<Cliente> clientes;

    public ClienteServiceImplement() {
        clientes = new ArrayList<>();
        // Agregar algunos clientes de ejemplo
        clientes.add(new Cliente(1, "Camilo", "Lopez", "Matilde Procel y Cantabria", "0951236547", "DNI", "1234567845", "camilolopez1", "kol"));
        clientes.add(new Cliente(2, "Andrea", "Granizo", "Leopoldo Aguirre y Cambridge", "0321456987", "DNI", "1234565678", "andrea16", "kol"));
        clientes.add(new Cliente(3, "Rodrigo", "Chavez", "Antonio Larrea y Arturo Borja", "0258741236", "DNI", "1245345678", "rodrigo25a", "kol"));
        clientes.add(new Cliente(4, "Alfredo", "Gutierrez", "Sangucho y Leonidas", "0658745632", "DNI", "1243465678", "alfred654", "kol"));
        clientes.add(new Cliente(5, "Mayte", "Diaz", "Rodrigo y Olmedo", "0154897631", "DNI", "1234596768", "mayteg15", "kol"));
        clientes.add(new Cliente(6, "Mayte", "Gonzalez", "Franchesco y Canturia", "0698745210", "DNI", "1923457678", "vmaysk45", "kol"));
        clientes.add(new Cliente(7, "Sandra", "Morales", "Antofagasta y Brasil", "0865402156", "DNI", "1234567888", "sandra46", "kol"));
        clientes.add(new Cliente(8, "Ariel", "Cantuña", "Cuenca y Marianas", "0365489712", "DNI", "1234457678", "ariel46", "kol"));
        clientes.add(new Cliente(9, "Leonardo", "Quishpe", "Canturia y Bridgeton", "0325641879", "DNI", "1992345678", "loenard678", "kol"));
        clientes.add(new Cliente(10, "Ruperto", "Dominguez", "Miami y Manabi", "0984561236", "DNI", "1234956798", "ruperto87", "kol"));
        clientes.add(new Cliente(11, "Juan", "Perez", "Manta y 10 de Agosto", "0807040609", "DNI", "1283459678", "juanres65", "kol"));
        clientes.add(new Cliente(12, "Diana", "Olmedo", "Azulejo y Guayas", "0569968558", "DNI", "1234056798", "diana98", "kol"));
        clientes.add(new Cliente(13, "Daniel", "Fernandez", "Alfredo y Galapagos", "0114477885", "DNI", "8706543291", "daniel9841a", "kol"));
    }

    @Override
    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    @Override
    public List<Cliente> obtenerClientes() {
        return clientes;
    }

    @Override
    public Cliente autenticar(String username, String password) {
        for (Cliente cliente : clientes) {
            if (cliente.getUsername().equals(username) && cliente.getPassword().equals(password)) {
                return cliente;
            }
        }
        return null; // Autenticación fallida
    }

    @Override
    public List<Cliente> listar() { // Implementación del método listar
        return obtenerClientes(); // Devuelve la lista de clientes existente
    }
}