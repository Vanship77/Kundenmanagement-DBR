package util;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import modelo.Cliente;

public class PdfUtil {
    public static void generarPdf(List<Cliente> clientes, String ruta) {
        // Crear el PdfWriter
        try {
            PdfWriter writer = new PdfWriter(new FileOutputStream(ruta));
            // Crear el PdfDocument
            PdfDocument pdfDoc = new PdfDocument(writer);
            // Crear el Document
            Document document = new Document(pdfDoc);

            // Lógica para agregar contenido al PDF
            for (Cliente cliente : clientes) {
                document.add(new Paragraph("ID: " + cliente.getId()));
                document.add(new Paragraph("Nombre: " + cliente.getNombre()));
                document.add(new Paragraph("Apellido: " + cliente.getApellido()));
                document.add(new Paragraph("Dirección: " + cliente.getDireccion()));
                document.add(new Paragraph("Teléfono: " + cliente.getTelefono()));
                document.add(new Paragraph("Tipo Documento: " + cliente.getTipoDocumento()));
                document.add(new Paragraph("Número Documento: " + cliente.getNumeroDocumento()));
                document.add(new Paragraph("Username: " + cliente.getUsername()));
                document.add(new Paragraph(" "));
            }

            // Cerrar el documento
            document.close();
            pdfDoc.close(); // Asegúrate de cerrar el PdfDocument también
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}