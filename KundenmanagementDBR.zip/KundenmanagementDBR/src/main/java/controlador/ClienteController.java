package controlador;

import modelo.Cliente;
import servicio.ClienteService;
import servicio.ClienteServiceImplement; // Asegúrate de importar la implementación

import java.util.List;

public class ClienteController {
    private ClienteService clienteService;

    public ClienteController() {
        // Cambia esto:
        // this.clienteService = new ClienteService();

        // A esto:
        this.clienteService = new ClienteServiceImplement(); // Usa la implementación
    }

    public void agregarCliente(Cliente cliente) {
        clienteService.agregarCliente(cliente);
    }

    public List<Cliente> obtenerClientes() {
        return clienteService.obtenerClientes();
    }

    public void descargarPdfClientes() {
        List<Cliente> clientes = obtenerClientes();
        // Lógica para generar y descargar el PDF
    }
}