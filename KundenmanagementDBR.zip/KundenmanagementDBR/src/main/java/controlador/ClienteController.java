package controlador;

import modelo.Cliente;
import servicio.ClienteService;
import servicio.ClienteServiceImplement;

import java.util.List;

public class ClienteController {
    private ClienteService ClienteService;

    public ClienteController() {
        this.ClienteService = new ClienteServiceImplement();
    }

    public void agregarCliente(Cliente cliente) {
        ClienteService.agregarCliente(cliente);
    }

    public List<Cliente> obtenerClientes() {
        return ClienteService.obtenerClientes();
    }

    public Cliente autenticarCliente(String username, String password) {
        return ClienteService.autenticar(username, password);
    }

    public void descargarPdfClientes() {
        List<Cliente> clientes = obtenerClientes();
        // Lógica para generar y descargar el PDF
    }
}